This library supports the RN2483 Microchip LORA module.
The Microchip RN2483 module provides LoRaWANTM protocol connectivity using a simple UART interface. 
This module handles the LoRaWAN Class A protocol and provides an optimized text command/response interface to the host system
